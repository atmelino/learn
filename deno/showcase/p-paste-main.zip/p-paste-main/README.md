# Ppaste

A simple pastebin website written in Deno Fresh and using Redis as a database.

### Usage

Start the project:

```
deno task start
```

This will watch the project directory and restart as necessary.



[![Made with Fresh](https://fresh.deno.dev/fresh-badge-dark.svg)](https://fresh.deno.dev)
